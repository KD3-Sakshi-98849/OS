#i/bin/bash

echo "Enter a number : "
read n

fact=1

for ((i=1; i<=n; i++))
do
     fact=$((fact*i))

     echo "Result : $fact "
done
